const express = require('express');
const fs = require('fs')

const app = express();
var bodyParser = require('body-parser');
const PORT = process.env.PORT || 8080;

var http = require('http');
var server = http.createServer(app);

app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static('public'));

app.listen(PORT, () => {
    console.log('Server connected at:', PORT);
});