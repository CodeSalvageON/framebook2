function redirect(){
  document.getElementById('frame-feed').innerHTML = '<iframe src="https://action3.codesalvageon.repl.co/redirect.html" width="600" height="700" frameBorder="0"></iframe>';
}